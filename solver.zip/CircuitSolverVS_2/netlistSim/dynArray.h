#include "netlistparser.h"

#ifndef DYN_ARRAY_H_
#define DYN_ARRAY_H_

class dynArray{

private:
	complex* ar;
	unsigned int maxIndexUsed;
	unsigned int capacity;

	void resizeArray(void);

public:
	dynArray(unsigned int size);
	~dynArray();
	void insert(int index, double real, double imag);
	complex* getArray(void);
	unsigned int getMaxIndexUsed(void);
	void toString();
};

#endif