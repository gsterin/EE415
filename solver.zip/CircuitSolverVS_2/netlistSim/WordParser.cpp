#include <iostream>
#include <fstream>
#include <string>
#include "WordParser.h"

using namespace std;

WordParser::WordParser(string line){
	this->line = line;
	this->notBlank = false;
	this->index = 0;
}

string WordParser::nextWord(){
	cout << "nextWord:";
	return line;
}
	
bool hasNext(){
	cout << "hasNext";
	return false;
}
