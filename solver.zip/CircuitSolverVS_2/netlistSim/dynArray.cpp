#include <stdlib.h>
#include "dynArray.h"

/**
 * Instantiates the dynamic array.
 * If size is <= 0 capacity is set to 10 by default
 */
dynArray::dynArray(unsigned int setSize){
	if(setSize <= 0){
		setSize = 10;
	}
	capacity = setSize;
	ar = (complex*)malloc(sizeof(complex)*capacity);

	maxIndexUsed = 0;

	int i;
	for(i = 0; i < capacity; i++){
		insert(i, 0.0, 0.0);
	}
}

/**
* Frees array when class is destroyed
*/
dynArray::~dynArray(){
	free(ar);
}

/* Inserts a complex with real value and imaginary value into index, resizing the array if necessary
 * Also tracks the maxIndexUsed, which is useful for tracking where to place new rows for partial nodal analysis 
 * If index < 0, this function does nothing
 */
void dynArray::insert(int index, double real, double imag){
	if(index < 0) return;

	complex value;
	value.im = imag;
	value.re = real;

	if(index >= capacity){
		resizeArray();
	}

	ar[index] = value;
	if(index > maxIndexUsed){
		maxIndexUsed = index;
	}
}

/**returns the tracked maxIndexUsed
  * 
  */
unsigned int dynArray::getMaxIndexUsed(){
	return maxIndexUsed;
}

/**
  * Returns a pointer to the current array
  */
complex* dynArray::getArray(void){
	return ar;
}

/**
  * Resizes array by allocating larger one, copying all elements into it, and saving it as the new ar property, freeing the old array
  */
void dynArray::resizeArray(void){
	complex* newAr = (complex*)malloc(sizeof(complex)*capacity*2);

	int i;
	for(i = 0; i < capacity; i++){
		newAr[i] = ar[i];
	}

	free(ar);
	ar = newAr;
	capacity *= 2;
}

void dynArray::toString(){
	int i;
	printf("[");
	for(i = 0; i <= maxIndexUsed; i++){
		printf("%f \n", ar[i].re);
	}
	printf("]");
}