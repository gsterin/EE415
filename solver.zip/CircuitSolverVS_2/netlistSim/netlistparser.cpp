#include <iostream>
#include <fstream>
#include <string>
#include "WordParser.h"

using namespace std;

void parseLine(string line);

int main (int argc, char *argv[]) {
	string line;
	ifstream myfile (argv[1]);
	if (myfile.is_open())
	{
		while (!myfile.eof())
		{
			getline (myfile,line);
			cout << line << endl;
			//parse the line
			parseLine(line);
		}	
		myfile.close();
	}

	else cout << "Unable to open file"; 

	return 0;
}

void parseLine(string line){
	cout << "parsing...";
}
