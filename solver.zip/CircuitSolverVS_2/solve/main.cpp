
// Main.cpp
// ----------------------------------------------------------------------------
// Title:   Mini PSpice
// Version: 4.09
// Date:    October 12, 2001
// Creator: Jonathan Lester 
//          (jlester@ee.washington.edu 
//            or
//           jlester@u.washington.edu)


// Includes
//#include <fstream.h>
#include <fstream>
#include <stdlib.h>

//#include <iostream.h>
#include <iostream>
#include <string.h>
#include <ctype.h>
//#include <iomanip.h>
#include <iomanip>
#include "spMatrix.h"
#include <stdio.h>
#include <math.h>
using namespace std;
// Constants
#define M_PI 3.1415926
#include <conio.h>

// Globals


#define spREAL double


extern "C"
{
	struct	spTemplate;
	//void    spMultiply(char * Matrix, spREAL * RHS, spREAL * Solution);
	//void	spClear( char * Matrix );
	//char *	spCreate( int Size, int Complex, int * Error );
	//void	spDestroy( char * Matrix );
	//int		spFactor( char * Matrix );
	//int		spGetAdmittance( char * Matrix, int Node1, int Node2, spTemplate * Template );
	//spREAL *spGetElement( char * Matrix, int Row, int Col );
	//int		spGetOnes( char * Matrix, int Pos, int Neg, int Eqn );
	//int		spGetQuad( char * Matrix, int Row1, int Row2, int Col1, int Col2, spTemplate * Template );
	//int		spOrderAndFactor( char * Matrix, spREAL * RHS, spREAL Threshold, spREAL AbsoluteThreshold, int DiagPivoting);
	//void	spPrint( char * Matrix, int PrintReordered, int Data, int Header );
	//void	spSolve( char * Matrix, spREAL * RHS, spREAL * Solution);
}



int main ( int argc, char **argv )
{
	spMatrix A;
	struct spTemplate Stamp[3];


	spError err;
	struct complex{
		double re;
		double im;
	} x[3],b[3];

	double f,omega;

	/*Create and build the matrix*/
	A=spCreate(2,1,&err);
	//if (err>=spFATAL){
	//	spErrorMessage(A,stderr,argv[0]);
	//	return 1;
	//}


	spGetAdmittance(A,1,0, &Stamp[0]);
	spGetAdmittance(A,1,2, &Stamp[1]);
	spGetAdmittance(A,0,3, &Stamp[2]);

	//if (spErrorState(A)>=spFATAL)
	//{
	//	spErrorMessage(A,stderr,argv[0]);
	//	return 1;
	//}
	

	/*Drive the circuit at node 1.*/
	b[0].re=0.0;  b[0].im=0.0;
	b[1].re=1.0;  b[1].im=0.0;
	b[2].re=0.0;  b[2].im=0.0;


	/*Load the matrix. */
		//spClear(A);
		//spADD_COMPLEX_QUAD(Stamp[0],1/50.0,1e-6*omega);
		spADD_REAL_QUAD(Stamp[0],1.0);
		spADD_REAL_QUAD(Stamp[1],1.0);
		spADD_REAL_QUAD(Stamp[2],2.0);
		
		//return 1;
	
	/*Solve the matrix equation Ax=b for x.*/
		err=spFactor(A);
		//if (err>=spFATAL){
			//spErrorMessage(A,stderr,argv[0]);
		//	return 1;

		//}
		//printf("x0=%6.2e\n",x[0]);
		spPrint(A, 0, 1, 1);
		spSolve(A, (spREAL *)b, (spREAL *)x);
		//printf("h=%6.2e\n",sqrt(x[2].re*x[2].re+x[2].im*x[2].im));
		printf("x0=%6.2e\n",x[0].re);
		printf("x1=%6.2e\n",x[1].re);
		printf("x2=%6.2e\n",x[2].re);
		getch();
		return 0;

}

